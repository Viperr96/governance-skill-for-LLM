# Instruction governance skills for LLM-driven projects

Three Claude Code skills, built from the approaches in `approaches.md`, that check and fix the files which steer a coding agent: `CLAUDE.md`, `AGENTS.md`, `.cursorrules`, Copilot instructions, `.claude/rules`, skills, agents, output styles, hooks and permission rules.

| skill | run it when | what it does |
|---|---|---|
| `/instruction-audit [path] [fix]` | you want a health check of every instruction file, or after a model upgrade | Runs a deterministic checker (bloat, vague rules, Opus 5 inverted classes, misplaced rules, conflict candidates, ungated enforcement, broken hooks), then judges only what the text cannot settle. `fix` applies the edits and shows before/after. |
| `/instruction-conflicts [path] [fix]` | the agent ignores a rule that is in the file, or follows it inconsistently | Groups every rule by subject across all files, tests each same-subject pair for "can both hold at once", names the winner under recency, proposes one resolution per conflict. |
| `/instruction-enforce <behavior>` | a rule must hold no matter what (length floor, forbidden command, protected path, step before commit) | Picks the weakest lever that holds (rule, output style, deny rule, hook, plugin) and generates it from templates, merging into `settings.json` without clobbering existing hooks. |

## Install

Project-level: the skills already live in `.claude/skills/` here. Copy that folder into any repository.

User-level, so they work in every project on this machine:

```
# PowerShell
Copy-Item -Recurse .claude\skills\instruction-* $HOME\.claude\skills\

# bash
cp -r .claude/skills/instruction-* ~/.claude/skills/
```

The three skills ship as a set: `instruction-conflicts` and `instruction-enforce` call the checker script inside `instruction-audit/scripts/`.

## The checker on its own

`audit_instructions.py` is stdlib-only Python 3.8+ and runs the same way in CI:

```
python .claude/skills/instruction-audit/scripts/audit_instructions.py . --no-user --fail-on error
python .claude/skills/instruction-audit/scripts/audit_instructions.py . --json --rules > audit.json
python .claude/skills/instruction-audit/scripts/audit_instructions.py . --only conflicts,enforcement
python .claude/skills/instruction-audit/scripts/audit_instructions.py . --list
```

It does not run a model. The same input gives the same output every time, which is the point: whether a rule names a construct, contradicts another, or loads where it applies are properties of the text, and asking the model to grade them is asking a stochastic judge a question with a definite answer.

## Layout

```
.claude/skills/
  instruction-audit/
    SKILL.md
    scripts/audit_instructions.py     # the deterministic checker
    reference/checks.md               # what each check measures and why
    reference/rule-writing.md         # the three-line rule shape, rewrite patterns, symptom table
  instruction-conflicts/
    SKILL.md
  instruction-enforce/
    SKILL.md
    reference/levers.md               # hook contracts, permission syntax, plugin layout
    templates/gate_length.py          # Stop hook: sends an over-long reply back once
    templates/deny_patterns.py        # PreToolUse hook: refuses matching commands and edits
    templates/reply-shape.md          # output style
    templates/settings.hooks.json     # settings.json fragment to merge
    templates/plugin.json             # plugin manifest
approaches.md                         # the extracted approaches from the three source articles
```

## Sources

Three DEV Community articles by Gábor Mészáros (Reporails), saved as `.mhtml` in this folder: "Opus 5: Delete your CLAUDE.md?", "Opus 5: How to Fix Verbose Output", and "Opus 5: The Cost of Instruction Conflicts". Format details come from the Claude Code docs on memory, skills, and hooks.
